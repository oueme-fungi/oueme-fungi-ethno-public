#' @keywords internal
"_PACKAGE"

#' @importFrom stats setNames rt dcauchy
#' @importFrom utils head tail getFromNamespace
#' @import ggplot2
#' @import scales
#' @import grid
#' @import gtable
NULL

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end
NULL
