#' @keywords internal
"_PACKAGE"

#' @importFrom methods as getMethod
#' @importFrom stats setNames rt dcauchy
#' @importFrom utils head tail getFromNamespace
#' @import ggplot2
#' @import scales
#' @import grid
#' @import gtable
#' @import data.table
NULL
