# Update

I intend to change the scope of this package upon ggplot v3.3.1 release. ggnomics will start focussing more on genomics tasks in the future. The functions that are not genomics related have been moved to [ggh4x](https://github.com/teunbrand/ggh4x) to avoid large bioconductor dependencies.

That is also why this readme no longer has installation instructions, to avoid anticipated disappointment. Consider this a soft deprication of the package in it's current state.

To glimpse the future, have a gander over here:

https://github.com/teunbrand/ggnomics/tree/BioC
