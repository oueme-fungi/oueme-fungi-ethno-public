library(testthat)
library(ggnomics)
library(ggplot2)

test_check("ggnomics")
