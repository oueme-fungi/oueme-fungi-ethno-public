library("testthat")
test_check("geoaxe")
